﻿About:
Lights Out is a minimalist game about perception. Brought to you by LudoBardos, a collective of game developers, it is a game to be played by 2 players sharing a keyboard. The players are trapped in a Belle Epóque house in France, and each stage refers to a different situation, with different characters in the same setting: one is the "predator", the other is the "prey".

How to play:
The first player, the predator, is in the left of the screen and must chase the second player, the prey, under a certain time. The second player must escape using one of the randomly open trapdoors in the house.

Player 1
Movement - Use W, A, S, D
Light - Space

Player 2
Movement - Use the arrows
Light - L

System requirements:
Windows XP, Windows Vista or Windows 7
DirectX 8-compatible graphics card with at least 32MB of video memory
Pentium or equivalent processor
DirectX 8-compatible sound card
156MB of memory or greater
800x600 or greater screen resolution with 16-bit or 32-bit colors

Contact information:
You can know more about the LudoBardos and their other games in their respective sites

Arthur Protasio - http://www.vagrantbard.com
Bruno Baère - http://sites.google.com/site/bbaere/about-me
Isabel Maciel
Leonardo Cardarelli - http://www.substancial8.com/
Rian Rezende